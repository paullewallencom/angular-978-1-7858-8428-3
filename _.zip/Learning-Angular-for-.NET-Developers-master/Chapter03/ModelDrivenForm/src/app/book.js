"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Book = (function () {
    function Book(name, author, publication) {
        this.name = name;
        this.author = author;
        this.publication = publication;
    }
    return Book;
}());
exports.Book = Book;
//# sourceMappingURL=book.js.map
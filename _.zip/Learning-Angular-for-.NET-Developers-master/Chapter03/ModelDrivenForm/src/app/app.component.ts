import { Component } from '@angular/core';

@Component({
  selector: 'first-model-form',
  template: '<book-form></book-form>'
})
export class AppComponent { }

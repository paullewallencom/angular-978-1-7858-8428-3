import { Component } from '@angular/core';

@Component({
  selector: 'first-template-form',
  template: '<book-form></book-form>'
})
export class AppComponent { }

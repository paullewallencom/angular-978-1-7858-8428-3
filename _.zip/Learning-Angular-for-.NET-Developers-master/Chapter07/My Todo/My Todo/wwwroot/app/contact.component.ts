﻿import { Component } from '@angular/core';

@Component({
    selector: 'contact-us',
    templateUrl: '/Home/Contact',
})
export class ContactComponent { }

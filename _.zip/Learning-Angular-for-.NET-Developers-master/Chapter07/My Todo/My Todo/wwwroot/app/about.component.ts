﻿import { Component } from '@angular/core';

@Component({
    selector: 'about-me',
    templateUrl: '/Home/About',
})
export class AboutComponent { }
